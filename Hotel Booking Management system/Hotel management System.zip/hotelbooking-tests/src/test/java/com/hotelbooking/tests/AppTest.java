package com.hotelbooking.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;

public class AppTest {
    private WebDriver driver;

    // Setup WebDriver for the test
    @BeforeClass
    public void setup() {
        // Setting up WebDriverManager to automatically manage browser drivers
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver"); // Optional if using WebDriverManager

        // Initializing WebDriver (for Chrome, you can use any browser)
        driver = new ChromeDriver();
    }

    // Sample test case using Selenium and TestNG
    @Test
    public void testExample() {
        // Navigate to a website (example: Google)
        driver.get("https://www.google.com");
        
        // Check if the page title contains "Google" (simple assertion)
        assertTrue(driver.getTitle().contains("Google"));
    }

    @Test
    public void testApp() {
        // Perform another Selenium-related test, if needed
        driver.get("https://www.example.com");
        
        // Check if the page title contains "Example"
        assertTrue(driver.getTitle().contains("Example"));
    }

    // Close the browser after tests are completed
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
